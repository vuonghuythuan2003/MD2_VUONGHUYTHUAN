create
    definer = root@localhost procedure create_product(IN in_product_name varchar(50), IN in_stock int,
                                                      IN in_cost_price double, IN in_selling_price double,
                                                      IN in_created_at datetime, IN in_category_id int)
begin
    INSERT INTO Products( product_name, stock, cost_price, selling_price, created_at
                        , category_id) VALUES (in_product_name, in_stock
                        , in_cost_price,
                        in_selling_price, in_created_at, in_category_id);
end;

