create
    definer = root@localhost procedure create_categories(IN in_categories_name varchar(50), IN in_categories_status bit)
BEGIN
    INSERT INTO Categories(category_name, category_status) VALUES (in_categories_name,
                                                                   in_categories_status);
end;

