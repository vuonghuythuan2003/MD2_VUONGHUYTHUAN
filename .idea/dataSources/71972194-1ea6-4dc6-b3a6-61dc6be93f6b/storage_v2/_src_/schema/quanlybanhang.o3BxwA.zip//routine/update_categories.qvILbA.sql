create
    definer = root@localhost procedure update_categories(IN in_categories_id int, IN in_categories_name varchar(50),
                                                         IN in_categories_status bit)
BEGIN
    UPDATE Categories
        SET category_name = in_categories_name,
            category_status = in_categories_status where category_id = in_categories_id;
end;

