create
    definer = root@localhost procedure Proc_FindAllCategories()
BEGIN
    SELECT * FROM Categories Where category_status = 0;
end;

