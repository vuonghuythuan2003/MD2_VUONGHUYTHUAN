create
    definer = root@localhost procedure find_id(IN id_categories int)
begin
        select * from Categories WHERE category_id = id_categories;
    end;

