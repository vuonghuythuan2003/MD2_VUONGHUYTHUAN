create
    definer = root@localhost procedure Proc_CountByCategoryes()
BEGIN
    SELECT category_id, COUNT(*) AS product_count
    From Products
        GROUP BY category_id;
end;

