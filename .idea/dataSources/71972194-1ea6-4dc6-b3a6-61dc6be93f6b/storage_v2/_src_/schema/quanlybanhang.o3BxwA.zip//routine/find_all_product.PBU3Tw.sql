create
    definer = root@localhost procedure find_all_product()
BEGIN
    SELECT * FROM Products;
end;

