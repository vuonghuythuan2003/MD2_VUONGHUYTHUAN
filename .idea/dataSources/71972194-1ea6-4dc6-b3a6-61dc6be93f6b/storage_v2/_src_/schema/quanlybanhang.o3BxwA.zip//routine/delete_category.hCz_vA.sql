create
    definer = root@localhost procedure delete_category(IN in_category_id int)
BEGIN
    UPDATE Categories
        SET category_status = 1 WHERE category_id = in_category_id;
end;

